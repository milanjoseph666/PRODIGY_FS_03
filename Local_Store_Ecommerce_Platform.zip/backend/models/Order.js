const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    productId: String,
    customerName: String,
    address: String,
    status: {
        type: String,
        default: "Processing"
    }
});

module.exports = mongoose.model('Order', orderSchema);