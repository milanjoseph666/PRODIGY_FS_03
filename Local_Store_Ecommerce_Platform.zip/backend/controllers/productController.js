const Product = require('../models/Product');

exports.getProducts = async (req, res) => {
    
    const sortBy = req.query.sortBy || 'name';
    const order = req.query.order === 'desc' ? -1 : 1;
    const filter = req.query.filter || {};
    const products = await Product.find(filter).sort({ [sortBy]: order });
    
    res.json(products);
};

exports.addProduct = async (req, res) => {
    const product = new Product(req.body);
    await product.save();
    res.status(201).json(product);
};

exports.deleteProduct = async (req, res) => {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ message: 'Product deleted' });
};