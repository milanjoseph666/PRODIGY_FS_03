const SupportRequest = require('../models/SupportRequest');

exports.sendSupport = async (req, res) => {
    const support = new SupportRequest(req.body);
    await support.save();
    res.status(201).json({ message: 'Support request received' });
};